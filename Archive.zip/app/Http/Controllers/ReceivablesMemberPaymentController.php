<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReceivablesMemberPaymentController extends Controller
{
    //
}
